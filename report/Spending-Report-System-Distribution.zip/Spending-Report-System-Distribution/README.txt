# 💰 Spending Report & Analysis System

## What This App Does
Automatically categorizes your spending, generates reports, and answers natural language questions about your finances - all locally on your computer. No cloud uploads. No API fees. 100% private.

## Installation

### System Requirements
- **macOS 10.13+** (Intel or Apple Silicon)
- **2GB free disk space**
- **500MB RAM available**

### Step 1: Download & Extract
1. Download the `Spending-Report-System-Distribution.zip` file
2. Extract it to a location of your choice
3. You should have a folder with `Spending-Report-System` inside

### Step 2: Prepare Your Bank Statements (First Time Only)
1. Export your bank transactions as **CSV file**
   - From your bank's website, usually: Download → CSV format
   - Must have columns: Date, Description, Amount
   
2. Save the CSV file as `statement.csv` in the same folder

### Step 3: Run the App
Double-click `Spending-Report-System` to launch the menu

## 📋 What You Can Do

### 1. Generate Spending Report
- Creates an Excel report with all transactions
- Automatically categorizes each expense
- Shows spending by category with charts
- Generates vendor analysis

### 2. Natural Language Queries (Optional)
- Ask questions like "How much did I spend on food?"
- Get spending comparisons and analysis
- Requires Ollama (local AI) - setup guide included
- **Note:** First time setup takes ~10 minutes, then instant queries

### 3. Manage Categories & Rules
- Customize spending categories
- Create your own rules for auto-categorization
- Override categories for specific vendors
- Save your custom rules

### 4. View Category Hierarchy
- See all categories and subcategories
- Understand organizational structure
- Modify hierarchy if needed

### 5. Export Rules
- Backup your custom rules
- Transfer rules to another computer
- Share rules with team members

## ⚡ Quick Start

1. Place your bank statement CSV in the same folder as the executable
2. Run the app
3. Select Option 1: Generate Spending Report
4. Wait for Excel file to be created
5. Open the Excel file to see your report

## 🤖 AI Features (Optional)

To use natural language queries:

### First Time: Install Ollama
1. Visit: https://ollama.ai
2. Download and install Ollama (takes 5 minutes)
3. Run the app again
4. Select Option 6 to install a language model (takes 10 minutes)
5. You're ready to ask questions!

### Usage
- Option 2: Ask questions about your spending
- Example: "What's my highest spending category?"
- The response is instant - model runs locally on your computer

## 📊 File Locations

Your files are stored in:
```
macOS → ~/Library/Preferences/SpenditApp/
        or same folder as the executable
```

**No data is uploaded to cloud. Everything stays on your computer.**

## ❓ FAQ

**Q: Is my financial data private?**
A: Yes! All data stays on your computer. No cloud upload.

**Q: Do I need internet?**
A: No, except for first-time setup. Everything runs locally.

**Q: Can I share my data?**
A: Yes, you have full control. Export features available in menu.

**Q: What if I don't want AI features?**
A: You don't need them. Reports work great without AI.

**Q: Can I use my own custom categories?**
A: Yes! Option 3 in the menu allows full customization.

## 🆘 Troubleshooting

**App won't start:**
- Try running from Terminal: `./Spending-Report-System`
- Check you have 500MB RAM available

**CSV import fails:**
- Verify CSV has: Date, Description, Amount columns
- Date format should be: YYYY-MM-DD

**AI responses are slow:**
- First query trains the model (takes 30 seconds)
- Subsequent queries are instant
- Internet not required

## 📝 Version

Version 2.0 - Built February 2026

## 💬 Support

This is a standalone application. No external support needed.
All code is open source - check the documentation folder.

---

**Made with ❤️ for financial privacy**
